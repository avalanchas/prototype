package com.example.prototype;

/**
 * Collection class for keys and constants used throughout the project
 */
public class DataKeys {
    public static final String TYPE = "image";
}
